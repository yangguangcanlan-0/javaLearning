package com.study.entity;

import lombok.Data;

@Data
public class Student {
    int id;
    String name;
    String sex;
    int grade;
}
